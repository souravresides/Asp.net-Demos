﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SecondMvcApp.Models;

namespace SecondMvcApp.Controllers
{
    public class TestController : Controller
    {
        // GET: Test/GetJson
        //[NonAction]
        [ActionName("GetJson")]
        public JsonResult Index()
        {
            string json = "{id:101, name:'Ashish'}";
            return Json(json, JsonRequestBehavior.AllowGet);
        }

        //Test/GetMessage/101
        [HttpGet]
        public ActionResult MakeAddition() 
        {
            return View();
        }

        [HttpPost]
        public ActionResult MakeAddition(Calculation calculation)
        {
            calculation.Result = calculation.No1 + calculation.No2;
            ViewBag.Calc = calculation;
            //ViewData["r"] = calculation;
            
            return View();
        }


    }
}