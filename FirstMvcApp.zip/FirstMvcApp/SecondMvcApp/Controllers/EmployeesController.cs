﻿using SecondMvcApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SecondMvcApp.Controllers
{
    public class EmployeesController : Controller
    {
        static List<Employee> emps = new List<Employee>
        {
            new Employee { Id = 101, Name = "Harshal", DOJ = DateTime.Now.AddDays(120), Salary =43000},
            new Employee { Id = 102, Name = "Veena", DOJ = DateTime.Now.AddDays(184), Salary =41000},
            new Employee { Id = 103, Name = "Gopal", DOJ = DateTime.Now.AddDays(96), Salary =35000},
            new Employee { Id = 104, Name = "Gauri", DOJ = DateTime.Now.AddDays(78), Salary =29000}
        };
        // GET: Employees
        public ActionResult Index()
        {            
            return View(emps);
        }

        // GET: Employees/Create
        [HttpGet] public ActionResult Create()
        {
            return View();
        }

        // POST: Employees/Create
        [HttpPost] public ActionResult Create(Employee employee)
        {
            emps.Add(employee);
            return RedirectToAction("Index", emps);
        }

        // GET: Employees/Edit
        [HttpGet] public ActionResult Edit(int id)
        {
            var emp = emps.Single(e => e.Id == id);
            return View(emp);
        }

        // POST: Employees/Create
        [HttpPost] public ActionResult Edit(Employee employee)
        {
            var emp = emps.Single(e => e.Id == employee.Id);
            emp.Name = employee.Name;
            emp.Salary = employee.Salary;
            emp.DOJ = employee.DOJ;            
            return RedirectToAction("Index", emps);
        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            var emp = emps.Single(e => e.Id == id);
            emps.Remove(emp);
            return RedirectToAction("Index", emps);
        }

        [HttpGet]
        public ActionResult Details(int id)
        {
            var emp = emps.Single(e => e.Id == id);
            return PartialView("_DetailsView", emp);
        }
    }
}