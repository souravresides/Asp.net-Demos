﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SecondMvcApp.Controllers
{
    public class AbcController : Controller
    {
        // GET: Abc/Hello1
        public ActionResult Hello1()
        {
            TempData["data"] = 10;
            return RedirectToAction("Hello2");
        }

        public ActionResult Hello2()
        {
            return View();
        }
    }
}