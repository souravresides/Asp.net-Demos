﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SecondMvcApp.Controllers
{
    [HandleError]
    public class Mvc5FiltersController : Controller
    {
        // GET: Mvc5Filters
        [OutputCache(Duration = 10)]
        public ActionResult Index()
        {
            ViewBag.DT = DateTime.Now.ToLongTimeString();
            return View();
        }

        [Authorize(Roles ="Trainer")]
        [HttpGet]
        public ActionResult GetInput()
        {
            return View();
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult GetInput(string txtInput)
        {
            ViewBag.Data = txtInput;
            return View();
        }

        [HandleError]
        public ActionResult TestException()
        {
            throw new Exception("Exception from TestException method!");
            return View();
        }
    }
}