﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SecondMvcApp.Models
{
    public class Calculation
    {
        public int No1 { get; set; }
        public int No2 { get; set; }
        public int Result { get; set; }
    }
}