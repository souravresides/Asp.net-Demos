﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SecondMvcApp.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime DOJ { get; set; }
        public double Salary { get; set; }
    }
}